require('dotenv').config();
const fs = require('fs');
const csv = require('csv-parser');
const mysql = require('mysql2/promise');

async function main() {
  // Validar que las variables de entorno estén presentes
  const {
    DB_HOST,
    DB_USER,
    DB_PASS,
    DB_NAME
  } = process.env;

  if (!DB_HOST || !DB_USER || !DB_PASS || !DB_NAME) {
    console.error('Faltan variables de entorno. Revisa el .env.');
    process.exit(1);
  }

  const dbConfig = {
    host: DB_HOST,
    user: DB_USER,
    password: DB_PASS,
    database: DB_NAME,
    waitForConnections: true,
    connectionLimit: 5,
    charset: 'utf8mb4'
  };

  const pool = mysql.createPool(dbConfig);

  try {
    // 1. Crear la tabla con restricción para evitar duplicados por nombre
    const createTableSQL = `
      CREATE TABLE IF NOT EXISTS aventureros (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(100) UNIQUE,
        clase VARCHAR(100),
        nivel INT
      ) CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci;
    `;
    await pool.query(createTableSQL);
    console.log('Tabla "aventureros" verificada/creada.');

    // 2. Leer el CSV y recolectar filas válidas
    const registros = [];
    await new Promise((resolve, reject) => {
      fs.createReadStream('aventureros.csv')
        .pipe(csv({ separator: ';', mapHeaders: ({ header }) => header.trim() }))
        .on('data', (row) => {
          const nombre = row.nombre ? row.nombre.trim() : null;
          const clase = row.clase ? row.clase.trim() : null;
          const nivel = row.nivel ? parseInt(row.nivel, 10) : null;

          if (!nombre || !clase || isNaN(nivel)) {
            console.warn('Fila ignorada por datos inválidos:', row);
            return;
          }

          registros.push({ nombre, clase, nivel });
        })
        .on('end', () => {
          console.log(`Leídos ${registros.length} registros válidos del CSV.`);
          resolve();
        })
        .on('error', (err) => {
          reject(err);
        });
    });

    if (registros.length === 0) {
      console.log('No hay registros válidos para insertar. Saliendo.');
      return;
    }

    // 3. Insertar en transacción, saltando duplicados
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      const insertSQL = `
        INSERT INTO aventureros (nombre, clase, nivel)
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE clase = VALUES(clase), nivel = VALUES(nivel)
      `;

      for (const r of registros) {
        await connection.execute(insertSQL, [r.nombre, r.clase, r.nivel]);
      }

      await connection.commit();
      console.log('Inserciones/actualizaciones completadas correctamente.');
    } catch (err) {
      await connection.rollback();
      console.error('Error en la transacción. Se hizo rollback.', err);
    } finally {
      connection.release();
    }
  } catch (err) {
    console.error('Error general en el script:', err);
  } finally {
    await pool.end();
    console.log('Conexión cerrada.');
  }
}

main().catch((e) => {
  console.error('Fallo inesperado:', e);
});
