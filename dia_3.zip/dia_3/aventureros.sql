/* Conécta el servidor (localhost) */
CREATE DATABASE IF NOT EXISTS aventureros_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS 'aventurero'@'localhost' IDENTIFIED BY 'TuContra123';
GRANT ALL PRIVILEGES ON aventureros_db.* TO 'aventurero'@'localhost';
FLUSH PRIVILEGES;

/* Verificar en MySQL Workbench */
USE aventureros_db;
SELECT * FROM aventureros; 
