# README.md: Importar Aventureros desde CSV a MySQL

Este repositorio contiene todo lo necesario para recibir un archivo CSV de aventureros y volcar su contenido a una tabla MySQL de forma segura y robusta. Se ofrecen dos métodos: mediante script directo (`importar_aventureros.js`) y a través de una API HTTP (`server.js`) que acepta uploads.

---

## 1. Descripción general
Se procesa un CSV delimitado por punto y coma (`;`) con columnas: `nombre`, `clase`, `nivel`. El sistema:
- Valida cada fila.
- Crea la tabla si no existe.
- Inserta o actualiza registros en MySQL usando transacciones y `ON DUPLICATE KEY UPDATE` para evitar duplicados.
- Expone un endpoint para recibir el CSV vía HTTP (opcional).

## 2. Pre-requisitos
- Node.js instalado (recomendado LTS).
- MySQL instalado y corriendo.
- MySQL Workbench o cliente similar para verificar.
- Tener acceso a crear base de datos y usuarios en MySQL.

## 3. Instalación inicial
En la carpeta del proyecto, ejecutar:

```bash
npm init -y
npm install express multer csv-parser mysql2 dotenv
```

## 4. Archivo .env (no subir a repositorios)
Crear un archivo .env en la raíz con este contenido (ajusta usuario/clave):

``` ini
DB_HOST=localhost
DB_USER=aventurero
DB_PASS=TuContra123
DB_NAME=aventureros_db
PORT=3000
```

Agregar .env a .gitignore:

``` bash
.env
```

## 5. Estructura de la base de datos (MySQL)
Conéctate por MySQL Workbench y ejecuta:

``` sql
CREATE DATABASE IF NOT EXISTS aventureros_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'aventurero'@'localhost' IDENTIFIED BY 'TuContra123';
GRANT ALL PRIVILEGES ON aventureros_db.* TO 'aventurero'@'localhost';
FLUSH PRIVILEGES;
```

La tabla se crea automáticamente desde el código si no existe. Su esquema:

``` sql
CREATE TABLE IF NOT EXISTS aventureros (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) UNIQUE,
  clase VARCHAR(100),
  nivel INT
) CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci;
```

## 6. Formato del CSV esperado
Nombre del archivo: aventureros.csv
Delimitador: ;
Encabezado obligatorio: nombre;clase;nivel
Ejemplo:

``` csv
nombre;clase;nivel
Santa Clouse;Mago;10
Thorgar;Guerrero;12
... (más filas)
```

Asegúrate de guardarlo en UTF-8 para conservar acentos.

## 7. Opción A: Script directo (importar_aventureros.js)
Este script lee aventureros.csv desde disco, valida, crea tabla y hace inserciones/actualizaciones en MySQL.

``` bash 
node importar_aventureros.js
```

Se usa .env para la configuración. Maneja:

- Validación de filas.
- Transacción para inserciones.
- Evita duplicados con UNIQUE + ON DUPLICATE KEY UPDATE.

## 8. Opción B: API REST con subida de CSV (server.js)
Expone un endpoint HTTP POST /upload que acepta multipart/form-data con el campo file conteniendo el CSV.

``` bash
curl -F "file=@aventureros.csv" http://localhost:3000/upload
```

Comportamiento:
-Valida tipo y tamaño del archivo.
- Parsea en streaming el CSV.
- Inserta o actualiza registros en transacción.
- Retorna resumen JSON con cantidad de válidos, inválidos y operados.

## 9. Ejemplo básico de respuesta esperada de la API
```json
{
  "mensaje": "Procesamiento completo",
  "total_en_csv": 20,
  "válidos": 20,
  "insertados_o_actualizados": 20,
  "inválidos": 0
}
```

## 10. Verificación en MySQL Workbench
Una vez corra el script o se use la API, en Workbench puedes verificar:

```sql
USE aventureros_db;
SELECT * FROM aventureros;
```
Deberías ver los aventureros con sus clases y niveles.

## 11. Manejo de errores comunes
- Conexión fallida: revisa que MySQL esté activo y que las credenciales en .env sean correctas.
- CSV mal formado: filas con campos faltantes o nivel no numérico se omiten y se reportan como inválidas en la API.
- Duplicados: no generan error; se actualiza la fila existente (misma columna nombre).
- Problemas de codificación: asegura que el CSV esté en UTF-8 y la base está usando utf8mb4.

## 12. Mejores prácticas y extensiones posibles
- Usar autenticación/limitación en el endpoint antes de exponerlo.
- Validar valores permitidos (por ejemplo, rangos de nivel o clases válidas).
- Registrar audit logs de subidas.
- Procesamiento asíncrono con colas si el CSV es muy grande.
- Reporte descargable de errores.

## 13. Comandos útiles

``` bash
# Instalar dependencias
npm install

# Ejecutar el servidor HTTP
node server.js

# Ejecutar solo importador directo
node importar_aventureros.js
```