# Importar Aventureros desde CSV a MySQL

Proyecto que convierte un Excel de aventureros a CSV y lo inserta en una base MySQL usando `fs`, `csv-parser` y `mysql2/promise`.

## Pasos realizados
1. **Convertir Excel a CSV** con formato `nombre;clase;nivel` (UTF-8).
2. **Conectar a MySQL** desde JavaScript.
3. **Leer y procesar CSV**: validar filas, crear tabla si no existe, insertar o actualizar con `ON DUPLICATE KEY UPDATE`.
4. **Opciones**:
   - Script directo: `node importar_aventureros.js`
   - API REST: subir CSV vía `POST /upload`.

## Requisitos
- Node.js y MySQL instalados.
- Archivo `.env` con credenciales:
  ```env
  DB_HOST=localhost
  DB_USER=aventurero
  DB_PASS=TuContra123
  DB_NAME=aventureros_db
  PORT=3000
  ```

## Autores
**Vanessa Gomez Lopez**
**Santiago Restrepo Arismendy**
